#!/usr/bin/env python3
"""
Database migration script
Creates tables and migrates data from JSON to database
"""
import sys
import os
from pathlib import Path
import json
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from flask import Flask
from database.models import db, User, Server, TunnelProvider, Bot
from web_panel.app import get_admin_config_path

def create_app():
    """Create Flask app for migration"""
    app = Flask(__name__)
    
    # Database configuration
    db_path = Path(__file__).parent.parent / 'panel_database.db'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    return app


def migrate_admin_credentials(app):
    """Migrate existing admin credentials from JSON to database"""
    config_path = get_admin_config_path()
    
    if not config_path.exists():
        print("⚠️  No existing admin credentials found. Skipping admin migration.")
        return None
    
    try:
        with open(config_path, 'r') as f:
            admin_config = json.load(f)
        
        with app.app_context():
            # Check if admin already exists
            existing_admin = User.query.filter_by(email=admin_config['email']).first()
            
            if existing_admin:
                print(f"✓ Admin user '{admin_config['email']}' already exists in database")
                return existing_admin
            
            # Create admin user
            admin = User(
                email=admin_config['email'],
                password_hash=admin_config['password_hash'],
                role='admin',
                is_active=True,
                created_at=datetime.fromtimestamp(admin_config.get('created_at', datetime.utcnow().timestamp()))
            )
            
            db.session.add(admin)
            db.session.commit()
            
            print(f"✓ Migrated admin user: {admin_config['email']}")
            return admin
            
    except Exception as e:
        print(f"❌ Error migrating admin credentials: {e}")
        return None


def migrate_servers(app, admin_user):
    """Migrate existing servers from JSON to database"""
    try:
        from app.core.server_store import get_server_store
        
        with app.app_context():
            server_store = get_server_store()
            servers_data = server_store.load_servers()
            
            if not servers_data:
                print("⚠️  No existing servers found. Skipping server migration.")
                return
            
            migrated_count = 0
            for name, server_data in servers_data.items():
                # Check if server already exists
                existing_server = Server.query.filter_by(name=name).first()
                
                if existing_server:
                    print(f"  - Server '{name}' already exists, skipping")
                    continue
                
                # Create server entry
                server = Server(
                    name=name,
                    version=server_data.get('version', 'unknown'),
                    port=server_data.get('port', 25565),
                    path=server_data.get('path', ''),
                    min_ram=server_data.get('min_ram', '1G'),
                    max_ram=server_data.get('max_ram', '2G'),
                    storage_path=server_data.get('storage_path', ''),
                    storage_limit=server_data.get('storage_limit', '10G'),
                    status='stopped',
                    created_by_id=admin_user.id if admin_user else None
                )
                
                db.session.add(server)
                migrated_count += 1
                print(f"  ✓ Migrated server: {name}")
            
            if migrated_count > 0:
                db.session.commit()
                print(f"✓ Migrated {migrated_count} servers to database")
            
    except Exception as e:
        print(f"❌ Error migrating servers: {e}")
        db.session.rollback()


def setup_default_tunnel_providers(app):
    """Set up default tunnel providers"""
    with app.app_context():
        providers = [
            {'name': 'playit', 'is_enabled': True, 'config': '{}'},
            {'name': 'ngrok', 'is_enabled': False, 'config': '{}'},
            {'name': 'custom', 'is_enabled': False, 'config': '{}'},
        ]
        
        for provider_data in providers:
            existing = TunnelProvider.query.filter_by(name=provider_data['name']).first()
            if not existing:
                provider = TunnelProvider(**provider_data)
                db.session.add(provider)
                print(f"  ✓ Created tunnel provider: {provider_data['name']}")
        
        db.session.commit()


def run_migration():
    """Run the complete migration"""
    print("=" * 60)
    print("🔄 Database Migration Starting...")
    print("=" * 60)
    
    app = create_app()
    
    print("\n1️⃣  Creating database tables...")
    with app.app_context():
        db.create_all()
    print("✓ Database tables created successfully")
    
    print("\n2️⃣  Migrating admin credentials...")
    admin_user = migrate_admin_credentials(app)
    
    print("\n3️⃣  Migrating servers...")
    migrate_servers(app, admin_user)
    
    print("\n4️⃣  Setting up tunnel providers...")
    setup_default_tunnel_providers(app)
    
    print("\n" + "=" * 60)
    print("✅ Migration completed successfully!")
    print("=" * 60)
    
    with app.app_context():
        admin_count = User.query.filter_by(role='admin').count()
        if admin_count > 0:
            print(f"\n🔐 Admin accounts created: {admin_count}")
            print("💡 You can now start the web panel with the new database")
        else:
            print("\n⚠️  No admin account found. You'll need to create one on first login.")


if __name__ == '__main__':
    run_migration()
