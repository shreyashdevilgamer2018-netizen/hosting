"""
Database models for multi-user Minecraft server panel
"""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
import bcrypt
import secrets

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model for authentication and authorization"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')  # 'admin' or 'user'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    assigned_servers = db.relationship('UserServer', back_populates='user', cascade='all, delete-orphan')
    api_keys = db.relationship('ApiKey', back_populates='user', cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def check_password(self, password):
        """Verify password"""
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
    
    def is_admin(self):
        """Check if user is admin"""
        return self.role == 'admin'
    
    def __repr__(self):
        return f'<User {self.email}>'


class ApiKey(db.Model):
    """API key model for external integrations like Discord bots"""
    __tablename__ = 'api_keys'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    user = db.relationship('User', back_populates='api_keys')
    
    @staticmethod
    def generate_key():
        """Generate a new API key"""
        return secrets.token_hex(32)  # 64 character hex string
    
    def __repr__(self):
        return f'<ApiKey {self.name}>'


class Server(db.Model):
    """Minecraft server model"""
    __tablename__ = 'servers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False, index=True)
    version = db.Column(db.String(50), nullable=False)
    port = db.Column(db.Integer, nullable=False)
    path = db.Column(db.String(500), nullable=False)
    min_ram = db.Column(db.String(20), nullable=False)
    max_ram = db.Column(db.String(20), nullable=False)
    storage_path = db.Column(db.String(500))
    storage_limit = db.Column(db.String(20))
    status = db.Column(db.String(20), default='stopped')  # 'running', 'stopped', 'starting'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Relationships
    created_by = db.relationship('User', backref='created_servers')
    assigned_users = db.relationship('UserServer', back_populates='server', cascade='all, delete-orphan')
    tunnel = db.relationship('PlayitTunnel', back_populates='server', uselist=False, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Server {self.name}>'


class UserServer(db.Model):
    """User-Server assignment table"""
    __tablename__ = 'user_servers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    server_id = db.Column(db.Integer, db.ForeignKey('servers.id'), nullable=False)
    permissions = db.Column(db.String(50), default='full')  # 'full', 'read-only', 'console-only'
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', back_populates='assigned_servers')
    server = db.relationship('Server', back_populates='assigned_users')
    
    # Ensure unique user-server combinations
    __table_args__ = (db.UniqueConstraint('user_id', 'server_id', name='unique_user_server'),)
    
    def __repr__(self):
        return f'<UserServer user_id={self.user_id} server_id={self.server_id}>'


class PlayitTunnel(db.Model):
    """Playit.gg tunnel configuration and status"""
    __tablename__ = 'playit_tunnels'
    
    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey('servers.id'), nullable=False)
    tunnel_id = db.Column(db.String(100), unique=True)  # Playit.gg tunnel ID
    endpoint_host = db.Column(db.String(255))  # e.g., "server.craft.playit.gg"
    endpoint_port = db.Column(db.Integer)  # External port
    provider = db.Column(db.String(50), default='playit')  # 'playit', 'ngrok', 'custom'
    status = db.Column(db.String(20), default='inactive')  # 'active', 'inactive', 'error'
    agent_key = db.Column(db.String(255))  # Playit agent secret key (if applicable)
    last_synced = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    server = db.relationship('Server', back_populates='tunnel')
    
    def __repr__(self):
        return f'<PlayitTunnel server={self.server_id} endpoint={self.endpoint_host}:{self.endpoint_port}>'


class TunnelProvider(db.Model):
    """User-configured tunnel providers"""
    __tablename__ = 'tunnel_providers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)  # 'playit', 'ngrok', 'custom'
    is_enabled = db.Column(db.Boolean, default=False)
    config = db.Column(db.Text)  # JSON config for the provider
    api_key = db.Column(db.String(255))  # API key if needed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<TunnelProvider {self.name}>'


class Bot(db.Model):
    """Discord bot hosting entries"""
    __tablename__ = 'bots'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    entry_point = db.Column(db.String(500))  # Path to entry file, e.g., bot.py
    path = db.Column(db.String(500))
    language = db.Column(db.String(50), default='python')
    status = db.Column(db.String(50), default='stopped')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    owner = db.relationship('User', backref='bots')

    def __repr__(self):
        return f'<Bot {self.name} owner={self.owner_id}>'
