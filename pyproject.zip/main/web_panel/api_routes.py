"""
API routes for external integrations like Discord bots
"""
from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from functools import wraps
from database.models import db, User, Server, ApiKey
import datetime

api_bp = Blueprint('api', __name__)

def require_api_key(f):
    """Decorator to require API key for access"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({'success': False, 'message': 'API key is required'}), 401
        
        key = ApiKey.query.filter_by(key=api_key, is_active=True).first()
        if not key:
            return jsonify({'success': False, 'message': 'Invalid API key'}), 401
        
        # Update last used timestamp
        key.last_used_at = datetime.datetime.utcnow()
        db.session.commit()
        
        # Set current user for the request
        request.api_user = key.user
        return f(*args, **kwargs)
    return decorated_function

# Browser-accessible API routes (no API key required)
@api_bp.route('/browser/servers/status', methods=['GET'])
@login_required
def browser_servers_status():
    """Get status of all servers - browser accessible"""
    user = current_user
    
    # Use the server_manager global instance from app
    from web_panel.app import get_server_manager
    server_manager = get_server_manager()
    
    # Get all servers the user has access to
    if user.is_admin():
        servers = Server.query.all()
    else:
        server_ids = [assignment.server_id for assignment in user.assigned_servers]
        servers = Server.query.filter(Server.id.in_(server_ids)).all()
    
    result = {'success': True, 'servers': {}}
    
    for server in servers:
        status = server_manager.get_server_status(server.name)
        # get_server_status returns a string ('running', 'stopped', 'unknown')
        result['servers'][server.name] = {
            'status': status if status else 'unknown',
            'running': status == 'running',
            'players': 0,
            'max_players': 0
        }
    
    return jsonify(result)

@api_bp.route('/versions', methods=['GET'])
@login_required
def get_versions():
    """Get available Minecraft server versions"""
    try:
        from web_panel.app import downloader
        
        versions_dict = downloader.get_paper_versions()
        
        versions_list = [
            {
                'id': version,
                'name': f"Paper {version}",
                'url': url
            }
            for version, url in versions_dict.items()
        ]
        
        return jsonify({
            'success': True,
            'versions': versions_list
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/browser/servers/create', methods=['POST'])
@login_required
def browser_create_server():
    """Create a new server - browser accessible (admin only)"""
    user = current_user
    
    if not user.is_admin():
        return jsonify({'success': False, 'message': 'Admin access required'}), 403
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request data'}), 400
    
    required_fields = ['name', 'version', 'min_ram', 'max_ram']
    for field in required_fields:
        if field not in data:
            return jsonify({'success': False, 'message': f'Missing required field: {field}'}), 400
    
    # Use the server_manager global instance from app
    from web_panel.app import get_server_manager, db
    from database.models import Server
    server_manager = get_server_manager()
    
    # Set default values for optional fields
    storage_path = data.get('storage_path', 'servers')
    storage_limit = data.get('storage_limit', '10')
    
    # Auto-allocate unique port or use provided port
    if 'port' in data and data['port']:
        port = int(data['port'])
        # Check if port is already in use
        existing = Server.query.filter_by(port=port).first()
        if existing:
            return jsonify({'success': False, 'message': f'Port {port} is already in use by server {existing.name}'}), 400
    else:
        # Auto-allocate next available port
        def get_next_port(start=25565, end=35565):
            used_ports = {s.port for s in Server.query.with_entities(Server.port).all() if s.port}
            candidate = start
            while candidate <= end and candidate in used_ports:
                candidate += 1
            if candidate > end:
                raise ValueError('No free ports available in range 25565-35565')
            return candidate
        
        try:
            port = get_next_port()
        except ValueError as e:
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # Create the server with the allocated port
    success = server_manager.create_server(
        name=data['name'],
        version=data['version'],
        min_ram=f"{data['min_ram']}G",
        max_ram=f"{data['max_ram']}G",
        storage_path=storage_path,
        port=port,
        storage_limit=int(storage_limit)
    )
    
    if success:
        # Create database entry
        path = f"servers/{data['name']}"  # Default path
        
        server = Server(
            name=data['name'],
            version=data['version'],
            port=port,
            path=path,
            min_ram=f"{data['min_ram']}G",
            max_ram=f"{data['max_ram']}G",
            storage_path=storage_path,
            storage_limit=storage_limit,
            created_by_id=user.id
        )
        
        db.session.add(server)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Server created successfully on port {port}',
            'server': {
                'id': server.id,
                'name': server.name,
                'port': server.port
            }
        })
    else:
        return jsonify({'success': False, 'message': 'Failed to create server'}), 500

@api_bp.route('/browser/servers/<string:name>/start', methods=['POST'])
@login_required
def browser_start_server(name):
    """Start a server - browser accessible"""
    user = current_user
    
    # Check if user has access to this server
    server = Server.query.filter_by(name=name).first()
    if not server:
        return jsonify({'success': False, 'message': 'Server not found'}), 404
    
    if not user.is_admin() and not any(assignment.server_id == server.id for assignment in user.assigned_servers):
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    # Use the server_manager from app.core to start the server
    from app.core.server_manager import get_server_manager
    server_manager = get_server_manager()
    
    if server_manager.start_server(name):
        return jsonify({'success': True, 'message': f'Server {name} is starting'})
    else:
        return jsonify({'success': False, 'message': f'Failed to start server {name}'}), 500

@api_bp.route('/browser/servers/<string:name>/stop', methods=['POST'])
@login_required
def browser_stop_server(name):
    """Stop a server - browser accessible"""
    user = current_user
    
    # Check if user has access to this server
    server = Server.query.filter_by(name=name).first()
    if not server:
        return jsonify({'success': False, 'message': 'Server not found'}), 404
    
    if not user.is_admin() and not any(assignment.server_id == server.id for assignment in user.assigned_servers):
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    # Use the server_manager from app.core to stop the server
    from app.core.server_manager import get_server_manager
    server_manager = get_server_manager()
    
    if server_manager.stop_server(name):
        return jsonify({'success': True, 'message': f'Server {name} is stopping'})
    else:
        return jsonify({'success': False, 'message': f'Failed to stop server {name}'}), 500

@api_bp.route('/keys', methods=['POST'])
@login_required
def create_api_key():
    """Create a new API key"""
    if not current_user.is_admin():
        return jsonify({'success': False, 'message': 'Admin access required'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'success': False, 'message': 'Key name is required'}), 400
    
    key = ApiKey(
        key=ApiKey.generate_key(),
        name=data['name'],
        user_id=current_user.id
    )
    
    db.session.add(key)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'key': {
            'id': key.id,
            'name': key.name,
            'key': key.key,  # Only show full key on creation
            'created_at': key.created_at.isoformat(),
            'is_active': key.is_active
        }
    })

@api_bp.route('/keys/<int:key_id>', methods=['DELETE'])
@login_required
def delete_api_key(key_id):
    """Delete an API key"""
    if not current_user.is_admin():
        return jsonify({'success': False, 'message': 'Admin access required'}), 403
    
    key = ApiKey.query.filter_by(id=key_id, user_id=current_user.id).first()
    if not key:
        return jsonify({'success': False, 'message': 'API key not found'}), 404
    
    db.session.delete(key)
    db.session.commit()
    
    return jsonify({'success': True})

@api_bp.route('/keys/<int:key_id>/toggle', methods=['POST'])
@login_required
def toggle_api_key(key_id):
    """Toggle API key active status"""
    if not current_user.is_admin():
        return jsonify({'success': False, 'message': 'Admin access required'}), 403
    
    key = ApiKey.query.filter_by(id=key_id, user_id=current_user.id).first()
    if not key:
        return jsonify({'success': False, 'message': 'API key not found'}), 404
    
    key.is_active = not key.is_active
    db.session.commit()
    
    return jsonify({'success': True, 'is_active': key.is_active})

@api_bp.route('/browser/check-admin', methods=['GET'])
@login_required
def check_admin_status():
    """Check if current user is admin"""
    return jsonify({'is_admin': current_user.is_admin()})

# API endpoints for Discord bot integration
@api_bp.route('/bot/servers', methods=['GET'])
@require_api_key
def list_servers():
    """List all servers for the API user"""
    user = request.api_user
    
    if user.is_admin():
        # Admins can see all servers
        servers = Server.query.all()
    else:
        # Regular users can only see assigned servers
        servers = [assignment.server for assignment in user.assigned_servers]
    
    return jsonify({
        'success': True,
        'servers': [{
            'id': server.id,
            'name': server.name,
            'version': server.version,
            'port': server.port,
            'status': server.status,
            'created_at': server.created_at.isoformat()
        } for server in servers]
    })

@api_bp.route('/bot/servers/<string:server_name>/start', methods=['POST'])
@require_api_key
def start_server(server_name):
    """Start a server"""
    user = request.api_user
    
    # Check if user has access to this server
    server = Server.query.filter_by(name=server_name).first()
    if not server:
        return jsonify({'success': False, 'message': 'Server not found'}), 404
    
    if not user.is_admin() and not any(assignment.server_id == server.id for assignment in user.assigned_servers):
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    # Use the server_manager from app.core to start the server
    from app.core.server_manager import get_server_manager
    server_manager = get_server_manager()
    
    success = server_manager.start_server(server_name)
    if success:
        server.status = 'starting'
        db.session.commit()
        return jsonify({'success': True, 'message': f'Server {server_name} is starting'})
    else:
        return jsonify({'success': False, 'message': f'Failed to start server {server_name}'}), 500

@api_bp.route('/bot/servers/<string:server_name>/stop', methods=['POST'])
@require_api_key
def stop_server(server_name):
    """Stop a server"""
    user = request.api_user
    
    # Check if user has access to this server
    server = Server.query.filter_by(name=server_name).first()
    if not server:
        return jsonify({'success': False, 'message': 'Server not found'}), 404
    
    if not user.is_admin() and not any(assignment.server_id == server.id for assignment in user.assigned_servers):
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    # Use the server_manager from app.core to stop the server
    from app.core.server_manager import get_server_manager
    server_manager = get_server_manager()
    
    success = server_manager.stop_server(server_name)
    if success:
        server.status = 'stopped'
        db.session.commit()
        return jsonify({'success': True, 'message': f'Server {server_name} is stopping'})
    else:
        return jsonify({'success': False, 'message': f'Failed to stop server {server_name}'}), 500

@api_bp.route('/bot/servers/<string:server_name>/status', methods=['GET'])
@require_api_key
def server_status(server_name):
    """Get server status"""
    user = request.api_user
    
    # Check if user has access to this server
    server = Server.query.filter_by(name=server_name).first()
    if not server:
        return jsonify({'success': False, 'message': 'Server not found'}), 404
    
    if not user.is_admin() and not any(assignment.server_id == server.id for assignment in user.assigned_servers):
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    # Use the server_manager global instance from app
    from web_panel.app import get_server_manager
    server_manager = get_server_manager()
    
    status = server_manager.get_server_status(server_name)
    # get_server_status returns a string ('running', 'stopped', 'unknown')
    return jsonify({
        'success': True,
        'server': {
            'name': server.name,
            'status': status if status else 'unknown',
            'running': status == 'running',
            'players': 0,
            'max_players': 0
        }
    })

@api_bp.route('/bot/servers/status', methods=['GET'])
@require_api_key
def all_servers_status():
    """Get status of all servers"""
    user = request.api_user
    
    # Use the server_manager global instance from app
    from web_panel.app import get_server_manager
    server_manager = get_server_manager()
    
    # Get all servers the user has access to
    if user.is_admin():
        servers = Server.query.all()
    else:
        server_ids = [assignment.server_id for assignment in user.assigned_servers]
        servers = Server.query.filter(Server.id.in_(server_ids)).all()
    
    result = {'success': True, 'servers': {}}
    
    for server in servers:
        status = server_manager.get_server_status(server.name)
        # get_server_status returns a string ('running', 'stopped', 'unknown')
        result['servers'][server.name] = {
            'status': status if status else 'unknown',
            'running': status == 'running',
            'players': 0,
            'max_players': 0
        }
    
    return jsonify(result)

@api_bp.route('/bot/servers/create', methods=['POST'])
@require_api_key
def create_server():
    """Create a new server (admin only)"""
    user = request.api_user
    
    if not user.is_admin():
        return jsonify({'success': False, 'message': 'Admin access required'}), 403
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Invalid request data'}), 400
    
    required_fields = ['name', 'version', 'min_ram', 'max_ram']
    for field in required_fields:
        if field not in data:
            return jsonify({'success': False, 'message': f'Missing required field: {field}'}), 400
    
    # Use the server_manager global instance from app
    from web_panel.app import get_server_manager
    server_manager = get_server_manager()
    
    # Set default values for optional fields
    storage_path = data.get('storage_path', 'servers')
    storage_limit = data.get('storage_limit', '10')
    
    # Create the server
    success, message = server_manager.create_server(
        name=data['name'],
        version=data['version'],
        min_ram=data['min_ram'],
        max_ram=data['max_ram'],
        storage_path=storage_path,
        storage_limit=storage_limit
    )
    
    if success:
        # Create database entry
        port = server_manager.get_server_port(data['name'])
        path = server_manager.get_server_path(data['name'])
        
        server = Server(
            name=data['name'],
            version=data['version'],
            port=port,
            path=path,
            min_ram=data['min_ram'],
            max_ram=data['max_ram'],
            storage_path=storage_path,
            storage_limit=storage_limit,
            created_by_id=user.id
        )
        
        db.session.add(server)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Server created successfully',
            'server': {
                'id': server.id,
                'name': server.name,
                'port': server.port
            }
        })
    else:
        return jsonify({'success': False, 'message': message}), 500