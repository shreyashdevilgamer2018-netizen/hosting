"""
Playit.gg integration module for automatic tunnel creation
"""
import subprocess
import json
import os
from pathlib import Path
from database.models import db, PlayitTunnel, TunnelProvider


class PlayitManager:
    """Manage Playit.gg tunnels for Minecraft servers"""
    
    def __init__(self):
        self.playit_path = Path(__file__).parent.parent / 'playit'
        self.agent_running = False
    
    def is_playit_enabled(self):
        """Check if Playit.gg is enabled"""
        provider = TunnelProvider.query.filter_by(name='playit', is_enabled=True).first()
        return provider is not None
    
    def create_tunnel(self, server_id, server_name, local_port):
        """Create a new Playit.gg tunnel for a Minecraft server"""
        if not self.is_playit_enabled():
            return None, "Playit.gg is not enabled"
        
        try:
            # For now, create a placeholder tunnel
            # In production, this would interact with Playit.gg API or agent
            tunnel = PlayitTunnel(
                server_id=server_id,
                tunnel_id=f"tunnel-{server_name}-{local_port}",
                endpoint_host=f"{server_name.lower()}.craft.playit.gg",
                endpoint_port=self._get_random_port(),
                provider='playit',
                status='active'
            )
            
            db.session.add(tunnel)
            db.session.commit()
            
            return tunnel, None
        except Exception as e:
            db.session.rollback()
            return None, str(e)
    
    def delete_tunnel(self, tunnel_id):
        """Delete a Playit.gg tunnel"""
        tunnel = PlayitTunnel.query.get(tunnel_id)
        if not tunnel:
            return False, "Tunnel not found"
        
        try:
            db.session.delete(tunnel)
            db.session.commit()
            return True, None
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    def get_tunnel_for_server(self, server_id):
        """Get tunnel information for a server"""
        tunnel = PlayitTunnel.query.filter_by(server_id=server_id).first()
        if not tunnel:
            return None
        
        return {
            'id': tunnel.id,
            'endpoint_host': tunnel.endpoint_host,
            'endpoint_port': tunnel.endpoint_port,
            'provider': tunnel.provider,
            'status': tunnel.status,
            'connection_string': f"{tunnel.endpoint_host}:{tunnel.endpoint_port}"
        }
    
    def _get_random_port(self):
        """Get a random high port number for tunnel"""
        import random
        return random.randint(30000, 60000)
    
    def sync_tunnel_status(self, tunnel_id):
        """Sync tunnel status with Playit.gg service"""
        # Placeholder for future implementation
        tunnel = PlayitTunnel.query.get(tunnel_id)
        if tunnel:
            tunnel.status = 'active'
            db.session.commit()
        return True


# Global instance
playit_manager = PlayitManager()
