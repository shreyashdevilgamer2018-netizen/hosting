"""
Authentication module using database
"""
from datetime import datetime
from functools import wraps
from flask import session, redirect, url_for, jsonify, request
from flask_login import LoginManager, current_user, login_user, logout_user
from database.models import db, User, Server, UserServer

# Initialize Flask-Login
login_manager = LoginManager()


@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    return User.query.get(int(user_id))


def init_auth(app):
    """Initialize authentication system"""
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    return login_manager


def login_required(f):
    """Decorator to require login for protected routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.is_json:
                return jsonify({'success': False, 'message': 'Authentication required'}), 401
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.is_json:
                return jsonify({'success': False, 'message': 'Authentication required'}), 401
            return redirect(url_for('login'))
        
        if not current_user.is_admin():
            if request.is_json:
                return jsonify({'success': False, 'message': 'Admin access required'}), 403
            return redirect(url_for('dashboard'))
        
        return f(*args, **kwargs)
    return decorated_function


def server_access_required(f):
    """Decorator to check if user has access to the server"""
    @wraps(f)
    def decorated_function(server_name, *args, **kwargs):
        if not current_user.is_authenticated:
            if request.is_json:
                return jsonify({'success': False, 'message': 'Authentication required'}), 401
            return redirect(url_for('login'))
        
        # Admin has access to all servers
        if current_user.is_admin():
            return f(server_name, *args, **kwargs)
        
        # Check if user has access to this server
        server = Server.query.filter_by(name=server_name).first()
        if not server:
            if request.is_json:
                return jsonify({'success': False, 'message': 'Server not found'}), 404
            return redirect(url_for('dashboard'))
        
        assignment = UserServer.query.filter_by(
            user_id=current_user.id,
            server_id=server.id
        ).first()
        
        if not assignment:
            if request.is_json:
                return jsonify({'success': False, 'message': 'Access denied'}), 403
            return redirect(url_for('dashboard'))
        
        return f(server_name, *args, **kwargs)
    return decorated_function


def get_user_servers(user_id):
    """Get all servers assigned to a user"""
    if not user_id:
        return []
    
    user = User.query.get(user_id)
    if not user:
        return []
    
    # Admin gets all servers
    if user.is_admin():
        return Server.query.all()
    
    # Regular users get only assigned servers
    assignments = UserServer.query.filter_by(user_id=user_id).all()
    server_ids = [a.server_id for a in assignments]
    return Server.query.filter(Server.id.in_(server_ids)).all() if server_ids else []


def authenticate_user(email, password):
    """Authenticate user and return user object if successful"""
    user = User.query.filter_by(email=email.lower().strip()).first()
    
    if not user:
        return None
    
    if not user.is_active:
        return None
    
    if not user.check_password(password):
        return None
    
    # Update last login
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    return user


def create_user(email, password, role='user', is_active=True):
    """Create a new user"""
    # Check if user already exists
    existing_user = User.query.filter_by(email=email.lower().strip()).first()
    if existing_user:
        return None, "User already exists"
    
    user = User(
        email=email.lower().strip(),
        role=role,
        is_active=is_active
    )
    user.set_password(password)
    
    try:
        db.session.add(user)
        db.session.commit()
        return user, None
    except Exception as e:
        db.session.rollback()
        return None, str(e)


def assign_server_to_user(user_id, server_id, permissions='full'):
    """Assign a server to a user"""
    # Check if user exists
    user = User.query.get(user_id)
    if not user:
        return False, "User not found"
    
    # Check if server exists
    server = Server.query.get(server_id)
    if not server:
        return False, "Server not found"
    
    # Check if assignment already exists
    existing = UserServer.query.filter_by(
        user_id=user_id,
        server_id=server_id
    ).first()
    
    if existing:
        return False, "Server already assigned to this user"
    
    assignment = UserServer(
        user_id=user_id,
        server_id=server_id,
        permissions=permissions
    )
    
    try:
        db.session.add(assignment)
        db.session.commit()
        return True, None
    except Exception as e:
        db.session.rollback()
        return False, str(e)


def remove_server_from_user(user_id, server_id):
    """Remove server assignment from user"""
    assignment = UserServer.query.filter_by(
        user_id=user_id,
        server_id=server_id
    ).first()
    
    if not assignment:
        return False, "Assignment not found"
    
    try:
        db.session.delete(assignment)
        db.session.commit()
        return True, None
    except Exception as e:
        db.session.rollback()
        return False, str(e)
