"""
Admin routes for user and server management
"""
from flask import Blueprint, request, jsonify, render_template, flash, redirect, url_for
from flask_login import current_user
from database.models import db, User, Server, UserServer, PlayitTunnel
from web_panel.auth import admin_required, create_user, assign_server_to_user, remove_server_from_user

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


@admin_bp.route('/users')
@admin_required
def users_page():
    """Admin page for managing users"""
    return render_template('admin/users.html')


@admin_bp.route('/users/<int:user_id>/servers')
@admin_required
def user_servers_page(user_id):
    """Admin page for managing user's server assignments"""
    user = User.query.get(user_id)
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('admin.users_page'))
    return render_template('admin/server_assignment.html', user=user)


@admin_bp.route('/api/users', methods=['GET'])
@admin_required
def get_users():
    """Get all users"""
    users = User.query.all()
    return jsonify({
        'success': True,
        'users': [{
            'id': u.id,
            'email': u.email,
            'role': u.role,
            'is_active': u.is_active,
            'created_at': u.created_at.isoformat() if u.created_at else None,
            'last_login': u.last_login.isoformat() if u.last_login else None
        } for u in users]
    })


@admin_bp.route('/api/users', methods=['POST'])
@admin_required
def create_new_user():
    """Create a new user"""
    data = request.json
    
    email = data.get('email', '').strip()
    password = data.get('password', '')
    role = data.get('role', 'user')
    
    if not email or not password:
        return jsonify({'success': False, 'message': 'Email and password required'}), 400
    
    if role not in ['admin', 'user']:
        return jsonify({'success': False, 'message': 'Invalid role'}), 400
    
    user, error = create_user(email, password, role)
    
    if error:
        return jsonify({'success': False, 'message': error}), 400
    
    return jsonify({
        'success': True,
        'message': f'User {email} created successfully',
        'user': {
            'id': user.id,
            'email': user.email,
            'role': user.role
        }
    })


@admin_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    """Delete a user"""
    # Prevent deleting yourself
    if user_id == current_user.id:
        return jsonify({'success': False, 'message': 'Cannot delete your own account'}), 400
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    try:
        db.session.delete(user)
        db.session.commit()
        return jsonify({'success': True, 'message': 'User deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@admin_bp.route('/api/users/<int:user_id>/toggle', methods=['POST'])
@admin_required
def toggle_user_status(user_id):
    """Toggle user active status"""
    user = User.query.get(user_id)
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    user.is_active = not user.is_active
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'User {"activated" if user.is_active else "deactivated"}',
        'is_active': user.is_active
    })


@admin_bp.route('/api/users/<int:user_id>/servers', methods=['GET'])
@admin_required
def get_user_servers(user_id):
    """Get servers assigned to a user"""
    user = User.query.get(user_id)
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    assignments = UserServer.query.filter_by(user_id=user_id).all()
    
    return jsonify({
        'success': True,
        'servers': [{
            'id': a.server.id,
            'name': a.server.name,
            'permissions': a.permissions,
            'assigned_at': a.assigned_at.isoformat() if a.assigned_at else None,
            'version': a.server.version
        } for a in assignments]
    })


@admin_bp.route('/api/users/<int:user_id>/servers', methods=['POST'])
@admin_required
def assign_server_to_user_route(user_id):
    """Assign a server to a user"""
    data = request.json
    server_id = data.get('server_id')
    permissions = data.get('permissions', 'full')
    
    if not server_id:
        return jsonify({'success': False, 'message': 'Server ID required'}), 400
    
    # Convert server_id to integer if it's a string
    try:
        server_id = int(server_id)
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Invalid server ID format'}), 400
    
    success, error = assign_server_to_user(user_id, server_id, permissions)
    
    if not success:
        return jsonify({'success': False, 'message': error}), 400
    
    return jsonify({'success': True, 'message': 'Server assigned successfully'})


@admin_bp.route('/api/users/<int:user_id>/servers/<int:server_id>', methods=['DELETE'])
@admin_required
def remove_server_from_user_route(user_id, server_id):
    """Remove server assignment from user"""
    success, error = remove_server_from_user(user_id, server_id)
    
    if not success:
        return jsonify({'success': False, 'message': error}), 404
    
    return jsonify({'success': True, 'message': 'Server assignment removed'})


@admin_bp.route('/api/servers/available', methods=['GET'])
@admin_required
def get_available_servers():
    """Get all servers for assignment"""
    servers = Server.query.all()
    return jsonify({
        'success': True,
        'servers': [{
            'id': s.id,
            'name': s.name,
            'port': s.port,
            'version': s.version,
            'status': s.status
        } for s in servers]
    })
