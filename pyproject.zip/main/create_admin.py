#!/usr/bin/env python3
"""
Simple script to create an admin account directly in the database
"""

import sys
import os
from pathlib import Path
import bcrypt

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))

def create_admin():
    """Create an admin account directly in the database"""
    try:
        from flask import Flask
        from database.models import db, User
        
        # Create a minimal Flask app
        app = Flask(__name__)
        db_path = Path(__file__).parent / 'panel_database.db'
        app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        db.init_app(app)
        
        print("🔐 CrazeDynPanel v2.0 - Admin Account Creation")
        print("=" * 50)
        
        email = input("📧 Enter admin email: ").strip().lower()
        password = input("🔑 Enter admin password: ")
        
        # Validate inputs
        if not email or '@' not in email:
            print("❌ Invalid email address")
            return False
        
        if len(password) < 8:
            print("❌ Password must be at least 8 characters long")
            return False
        
        # Hash the password
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        with app.app_context():
            # Check if user already exists
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                # Update existing user to admin
                existing_user.role = 'admin'
                existing_user.password_hash = password_hash
                existing_user.is_active = True
                db.session.commit()
                print(f"✅ Updated existing user {email} to admin role with new password")
            else:
                # Create new admin user
                new_admin = User(
                    email=email,
                    password_hash=password_hash,
                    role='admin',
                    is_active=True
                )
                db.session.add(new_admin)
                db.session.commit()
                print(f"✅ Created new admin user: {email}")
            
            print("🎉 Admin account created successfully!")
            print("🔑 You can now log in to the web panel with these credentials.")
            return True
    except Exception as e:
        print(f"❌ Error creating admin account: {e}")
        return False

if __name__ == "__main__":
    create_admin()