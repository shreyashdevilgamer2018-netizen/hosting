#!/bin/bash

# ─────────────────────────────────────────────────────────────────────
# 🚀 CrazeDynPanel VPS Setup Script
# ─────────────────────────────────────────────────────────────────────
# Version: 2.0
# Description: Simple VPS setup script for CrazeDynPanel

# Set up logging
LOG_FILE="/var/log/crazedynpanel-setup.log"
CONFIG_DIR="/etc/crazedynpanel"
CONFIG_FILE="$CONFIG_DIR/config.json"
INSTALL_DIR="/opt/crazedynpanel"
SYSTEMD_DIR="/etc/systemd/system"

# Colors for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to log messages
log() {
    local message="$1"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo -e "${timestamp} - ${message}" | tee -a "$LOG_FILE"
}

# Function to display colored messages
print_message() {
    local type=$1
    local message=$2
    
    case $type in
        "info")
            echo -e "${BLUE}[INFO]${NC} $message"
            ;;
        "success")
            echo -e "${GREEN}[SUCCESS]${NC} $message"
            ;;
        "warning")
            echo -e "${YELLOW}[WARNING]${NC} $message"
            ;;
        "error")
            echo -e "${RED}[ERROR]${NC} $message"
            ;;
        *)
            echo -e "$message"
            ;;
    esac
    
    log "$type - $message"
}

# Function to check if script is run as root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        print_message "error" "Please run this script as root"
        exit 1
    fi
}

# Function to create config directory and file if they don't exist
ensure_config() {
    if [ ! -d "$CONFIG_DIR" ]; then
        mkdir -p "$CONFIG_DIR"
        print_message "info" "Created config directory at $CONFIG_DIR"
    fi
    
    if [ ! -f "$CONFIG_FILE" ]; then
        echo '{}' > "$CONFIG_FILE"
        print_message "info" "Created config file at $CONFIG_FILE"
    fi
    
    if [ ! -d "$INSTALL_DIR" ]; then
        mkdir -p "$INSTALL_DIR"
        print_message "info" "Created installation directory at $INSTALL_DIR"
    fi
}

# Function to update config file
update_config() {
    local key=$1
    local value=$2
    
    # Create a temporary file
    local temp_file=$(mktemp)
    
    # Use jq to update the JSON file
    if ! command -v jq &> /dev/null; then
        apt-get update && apt-get install -y jq
    fi
    
    jq ".$key = \"$value\"" "$CONFIG_FILE" > "$temp_file"
    mv "$temp_file" "$CONFIG_FILE"
    
    print_message "info" "Updated config: $key = $value"
}

# Function to read from config file
read_config() {
    local key=$1
    local default=$2
    
    if ! command -v jq &> /dev/null; then
        apt-get update && apt-get install -y jq
    fi
    
    local value=$(jq -r ".$key // \"$default\"" "$CONFIG_FILE")
    echo "$value"
}

# Function to display banner
display_banner() {
    local company_name=$(read_config "company_name" "CrazeDynPanel")
    
    clear
    echo -e "${CYAN}"
    echo "─────────────────────────────────────────"
    echo "  🚀 $company_name VPS Setup"
    echo "─────────────────────────────────────────"
    echo -e "${NC}"
}

# Function to install Python and Java JDK
install_python_java() {
    print_message "info" "Installing Python and Java JDK..."
    
    # Update package lists
    apt update
    
    # Install Python 3 and pip
    apt install -y python3 python3-pip python3-dev
    
    # Install Java JDK
    apt install -y default-jdk
    
    # Verify installations
    python3_version=$(python3 --version)
    java_version=$(java -version 2>&1 | head -n 1)
    
    print_message "success" "Python installed: $python3_version"
    print_message "success" "Java installed: $java_version"
    
    # Update alternatives to ensure python command is available
    update-alternatives --install /usr/bin/python python /usr/bin/python3 1
    
    return 0
}

# Function to install dependencies
install_dependencies() {
    print_message "info" "Installing dependencies..."
    
    # Install system dependencies
    apt update
    apt install -y git curl wget unzip jq build-essential libssl-dev libffi-dev
    
    # Install Python packages
    pip3 install --upgrade pip
    pip3 install PyQt6 bcrypt Flask Flask-Login Flask-SQLAlchemy Flask-WTF Flask-Migrate
    pip3 install requests psutil python-dotenv Werkzeug==2.3.7 SQLAlchemy==2.0.23
    
    print_message "success" "Dependencies installed successfully"
    return 0
}

# Function to configure panel settings
configure_panel() {
    print_message "info" "Configuring panel settings..."
    
    # Prompt for panel port
    read -p "Enter panel port (default: 5000): " panel_port
    panel_port=${panel_port:-5000}
    
    # Prompt for company name
    read -p "Enter company name to display on panel: " company_name
    company_name=${company_name:-"CrazeDynPanel"}
    
    # Save panel settings to config
    update_config "panel_port" "$panel_port"
    update_config "company_name" "$company_name"
    
    # Create a .env file for the panel
    cat > "$INSTALL_DIR/.env" << EOL
FLASK_APP=web_panel.app
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)
PANEL_PORT=$panel_port
COMPANY_NAME=$company_name
EOL
    
    print_message "success" "Panel configuration completed"
}

# Function to create systemd service for auto-start
create_autostart_service() {
    print_message "info" "Creating auto-start service..."
    
    local panel_port=$(read_config "panel_port" "5000")
    
    # Create systemd service file
    cat > "$SYSTEMD_DIR/crazedynpanel.service" << EOL
[Unit]
Description=CrazeDynPanel Web Service
After=network.target

[Service]
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/launcher.py --web
Restart=always
RestartSec=5
Environment="PANEL_PORT=$panel_port"

[Install]
WantedBy=multi-user.target
EOL
    
    # Reload systemd, enable and start the service
    systemctl daemon-reload
    systemctl enable crazedynpanel.service
    systemctl start crazedynpanel.service
    
    print_message "success" "Auto-start service created and enabled"
}

# Function to setup admin configuration
setup_admin() {
    print_message "info" "Setting up admin configuration..."
    
    # Run the admin setup script
    cd "$INSTALL_DIR"
    python3 create_admin.py
    
    print_message "success" "Admin setup completed"
}

# Function to copy current directory to install directory
copy_files() {
    print_message "info" "Copying files to installation directory..."
    
    # Get the script's directory
    SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
    
    # Copy all files to the installation directory
    cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR"/
    
    print_message "success" "Files copied successfully"
}

# Function to update launcher.py to use environment variable for port
update_launcher() {
    print_message "info" "Updating launcher.py to use environment variable for port..."
    
    # Path to launcher.py
    LAUNCHER_PATH="$INSTALL_DIR/main/launcher.py"
    
    # Check if launcher.py exists
    if [ -f "$LAUNCHER_PATH" ]; then
        # Replace the fixed port with environment variable
        sed -i 's/port = 5000/port = int(os.environ.get("PANEL_PORT", 5000))/g' "$LAUNCHER_PATH"
        print_message "success" "Updated launcher.py to use PANEL_PORT environment variable"
    else
        print_message "warning" "launcher.py not found at $LAUNCHER_PATH"
    fi
}

# Main function
main() {
    # Check if running as root
    check_root
    
    # Ensure config directories exist
    ensure_config
    
    # Display banner
    display_banner
    
    print_message "info" "Starting CrazeDynPanel VPS setup..."
    
    # Install Python and Java
    install_python_java
    
    # Install dependencies
    install_dependencies
    
    # Copy files to installation directory
    copy_files
    
    # Update launcher.py to use environment variable for port
    update_launcher
    
    # Configure panel settings
    configure_panel
    
    # Setup admin
    setup_admin
    
    # Create auto-start service
    create_autostart_service
    
    print_message "success" "CrazeDynPanel setup completed successfully!"
    print_message "info" "Panel is running at http://$(hostname -I | awk '{print $1}'):$(read_config "panel_port" "5000")"
    print_message "info" "You can access the panel using the admin credentials you provided"
}

# Display instructions
echo -e "${GREEN}=== CrazeDynPanel VPS Setup Instructions ===${NC}"
echo -e "This script will install Python, Java JDK, and all required dependencies."
echo -e "It will also configure the panel port, company name, and set up auto-start on reboot."
echo -e ""
echo -e "${YELLOW}To run this script:${NC}"
echo -e "1. Upload this script to your VPS"
echo -e "2. Make it executable with: ${CYAN}chmod +x Setup_VPS.sh${NC}"
echo -e "3. Run it with root privileges: ${CYAN}sudo ./Setup_VPS.sh${NC}"
echo -e ""
echo -e "${YELLOW}Requirements:${NC}"
echo -e "- Ubuntu 20.04 or newer"
echo -e "- Root access"
echo -e ""
echo -e "Press Enter to continue or Ctrl+C to cancel..."
read

# Run the main function
main